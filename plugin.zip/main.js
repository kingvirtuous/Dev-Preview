"use strict";(()=>{var l={$schema:"https://acode.app/schema/plugin/v0.1.0.json",id:"acode.plugin.webpreview",name:"Web Preview",main:"main.js",version:"1.0.0",readme:"readme.md",changelogs:"changelog.md",repository:"",icon:"icon.png",files:[],minVersionCode:290,license:"MIT",keywords:["Web Preview","Live Preview","React","Vite","localhost","Developer Tools"],price:0,permissions:[],author:{name:"Your Name",email:"",github:""}};var h=class{baseUrl="";page=null;commands=null;actionStack=null;floatingButton=null;floatingButtonStyle=null;iframe=null;urlInput=null;backButton=null;refreshButton=null;menuButton=null;menu=null;isDragging=!1;hasMoved=!1;dragOffsetX=0;dragOffsetY=0;buttonX=null;buttonY=null;previewOpen=!1;actionId="web-preview.close";storageKey="web-preview.last-url";localPorts=[5173,5174,3e3,3001,8080,4321,5e3];defaultUrl="http://localhost:5173";currentMode="responsive";modes={responsive:{name:"Responsive",width:"100%",height:"100%"},mobile:{name:"Mobile",width:390,height:844},tablet:{name:"Tablet",width:768,height:1024},desktop:{name:"Desktop",width:1440,height:900}};async init(e){this.page=e,this.page.header&&(this.page.header.style.display="none"),this.commands=acode.require("commands"),this.actionStack=acode.require("actionStack"),this.createPage(),this.setupPageNavigation(),this.registerCommands(),this.createFloatingButton()}createPage(){let e=document.createElement("style");e.textContent=`
            .web-preview {
                width: 100%;
                height: 100%;
                display: flex;
                flex-direction: column;
                overflow: hidden;
                background: #1f1f1f;
                color: #ffffff;
            }

            .web-preview-toolbar {
                position: relative;
                width: 100%;
                display: flex;
                align-items: center;
                gap: 6px;
                padding: 8px;
                flex-shrink: 0;
                box-sizing: border-box;
                background: #1f1f1f;
            }

            .web-preview-nav-button {
                width: 38px;
                height: 38px;
                padding: 0;
                border: none;
                border-radius: 7px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                background: #2d2d2d;
                color: #ffffff;
                font-size: 22px;
                font-weight: 700;
                cursor: pointer;
            }

            .web-preview-nav-button:active {
                background: #3a3a3a;
            }

            .web-preview-url-wrapper {
                flex: 1;
                min-width: 0;
                height: 38px;
                display: flex;
                align-items: center;
                border-radius: 8px;
                overflow: hidden;
                background: #2d2d2d;
            }

            .web-preview-url {
                width: 100%;
                min-width: 0;
                height: 100%;
                padding: 0 8px;
                border: none;
                outline: none;
                background: transparent;
                color: #ffffff;
                font-size: 14px;
                box-sizing: border-box;
            }

            .web-preview-url::placeholder {
                color: #aaaaaa;
            }

            .web-preview-menu-button {
                width: 38px;
                height: 38px;
                padding: 0;
                border: none;
                border-radius: 7px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                background: #2d2d2d;
                color: #ffffff;
                font-size: 24px;
                font-weight: 700;
                cursor: pointer;
            }

            .web-preview-menu-button:active {
                background: #3a3a3a;
            }

            .web-preview-content {
                flex: 1;
                min-height: 0;
                width: 100%;
                overflow: auto;
                position: relative;
                background: #eeeeee;
                box-sizing: border-box;
            }

            .web-preview-viewport {
                width: 100%;
                min-height: 100%;
                display: flex;
                justify-content: center;
                align-items: flex-start;
                padding: 0;
                box-sizing: border-box;
            }

            .web-preview-frame {
                display: block;
                flex-shrink: 0;
                width: 100%;
                height: 100%;
                border: 0;
                background: #ffffff;
                transition:
                    width 0.2s ease,
                    height 0.2s ease;
            }

            .web-preview-menu {
                position: absolute;
                top: 52px;
                right: 8px;
                width: 220px;
                padding: 6px;
                border-radius: 10px;
                background: #292929;
                box-shadow:
                    0 8px 28px
                    rgba(0, 0, 0, 0.45);
                z-index: 100000;
                display: none;
                box-sizing: border-box;
            }

            .web-preview-menu.open {
                display: block;
            }

            .web-preview-menu-item {
                width: 100%;
                min-height: 42px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 10px;
                padding: 8px 10px;
                border: none;
                border-radius: 7px;
                background: transparent;
                color: #ffffff;
                text-align: left;
                font-size: 14px;
                cursor: pointer;
                box-sizing: border-box;
            }

            .web-preview-menu-item:active {
                background: #3a3a3a;
            }

            .web-preview-menu-item-left {
                display: flex;
                align-items: center;
                gap: 10px;
                min-width: 0;
            }

            .web-preview-menu-icon {
                width: 24px;
                text-align: center;
                flex-shrink: 0;
            }

            .web-preview-menu-check {
                width: 20px;
                text-align: center;
                color: #ffffff;
                flex-shrink: 0;
            }

            .web-preview-menu-divider {
                height: 1px;
                margin: 6px 4px;
                background: #444444;
            }

            @media (max-width: 600px) {
                .web-preview-toolbar {
                    gap: 4px;
                    padding: 6px;
                }

                .web-preview-nav-button {
                    width: 34px;
                    height: 36px;
                }

                .web-preview-menu-button {
                    width: 34px;
                    height: 36px;
                }

                .web-preview-url-wrapper {
                    height: 36px;
                }

                .web-preview-menu {
                    top: 48px;
                    right: 6px;
                }
            }
        `,this.page.appendChild(e);let i=this.getSavedUrl()||this.defaultUrl;this.page.innerHTML+=`
            <div class="web-preview">

                <div class="web-preview-toolbar">

                    <button
                        class="web-preview-nav-button web-preview-back"
                        type="button"
                        title="Return to editor"
                        aria-label="Return to editor"
                    >
                        \u2190
                    </button>

                    <div
                        class="web-preview-url-wrapper"
                    >

                        <input
                            class="web-preview-url"
                            type="url"
                            placeholder="localhost:5173"
                            value="${i}"
                        />

                    </div>

                    <button
                        class="web-preview-nav-button web-preview-reload"
                        type="button"
                        title="Reload"
                        aria-label="Reload"
                    >
                        \u21BB
                    </button>

                    <button
                        class="web-preview-menu-button"
                        type="button"
                        title="Preview options"
                        aria-label="Preview options"
                    >
                        \u22EE
                    </button>

                    <div
                        class="web-preview-menu"
                    >

                        <button
                            class="web-preview-menu-item web-preview-detect"
                            type="button"
                        >

                            <span
                                class="web-preview-menu-item-left"
                            >

                                <span
                                    class="web-preview-menu-icon"
                                >
                                    \u{1F50D}
                                </span>

                                <span>
                                    Detect Local Server
                                </span>

                            </span>

                        </button>

                    </div>

                </div>

                <div
                    class="web-preview-content"
                >

                    <div
                        class="web-preview-viewport"
                    >

                        <iframe
                            class="web-preview-frame"
                            title="Web Preview"
                        ></iframe>

                    </div>

                </div>

            </div>
        `,this.urlInput=this.page.querySelector(".web-preview-url"),this.iframe=this.page.querySelector(".web-preview-frame"),this.backButton=this.page.querySelector(".web-preview-back"),this.refreshButton=this.page.querySelector(".web-preview-reload"),this.menuButton=this.page.querySelector(".web-preview-menu-button"),this.menu=this.page.querySelector(".web-preview-menu"),this.backButton.addEventListener("click",()=>{this.close()}),this.refreshButton.addEventListener("click",()=>{this.refresh()}),this.menuButton.addEventListener("click",n=>{n.stopPropagation(),this.toggleMenu()}),this.urlInput.addEventListener("keydown",n=>{n.key==="Enter"&&this.loadUrl()}),this.page.querySelector(".web-preview-detect").addEventListener("click",()=>{this.closeMenu(),this.detectLocalServer()}),document.addEventListener("pointerdown",n=>{this.menu&&!this.menu.contains(n.target)&&n.target!==this.menuButton&&this.closeMenu()}),this.iframe.addEventListener("load",()=>{this.hideEmptyState()}),this.setPreviewMode("responsive")}setupPageNavigation(){let e=this.page;e.show=()=>{var t,i;this.previewOpen||(this.previewOpen=!0,this.hideFloatingButton(),(t=this.actionStack)==null||t.remove(this.actionId),(i=this.actionStack)==null||i.push({id:this.actionId,action:()=>{this.closeFromBack()}}),app.append(e),this.detectLocalServer())}}toggleMenu(){this.menu&&this.menu.classList.toggle("open")}closeMenu(){this.menu&&this.menu.classList.remove("open")}setPreviewMode(e){if(!this.modes[e])return;this.currentMode=e;let t=this.page.querySelector(".web-preview-viewport");if(!t||!this.iframe)return;let i=this.modes[e];e==="responsive"?(t.style.width="100%",t.style.height="100%",t.style.minHeight="100%",t.style.alignItems="flex-start",t.style.justifyContent="center",this.iframe.style.width="100%",this.iframe.style.height="100%",this.iframe.style.boxShadow="none"):(t.style.width=`${i.width}px`,t.style.height=`${i.height}px`,t.style.minHeight=`${i.height}px`,t.style.alignItems="flex-start",t.style.justifyContent="center",this.iframe.style.width=`${i.width}px`,this.iframe.style.height=`${i.height}px`,this.iframe.style.boxShadow="0 4px 18px rgba(0,0,0,0.25)"),this.updateModeChecks(),this.closeMenu()}updateModeChecks(){this.page.querySelectorAll("[data-mode]").forEach(t=>{let i=t.querySelector(".web-preview-menu-check");i&&(i.textContent=t.dataset.mode===this.currentMode?"\u2713":"")})}createFloatingButton(){let e=document.createElement("style");e.id="web-preview-floating-button-style",e.textContent=`
            .web-preview-floating-button {
                position: fixed;

                right: 20px;
                bottom: 100px;

                width: 60px;
                height: 60px;

                padding: 0;

                border: none;
                border-radius: 50%;

                display: flex;
                align-items: center;
                justify-content: center;

                background: #1f1f1f;

                color: #ffffff;

                box-shadow:
                    0 5px 16px
                    rgba(0, 0, 0, 0.35);

                z-index: 99999;

                cursor: grab;

                touch-action: none;

                user-select: none;
                -webkit-user-select: none;

                transform:
                    translate3d(0, 0, 0)
                    scale(1);

                transition:
                    transform 0.18s
                    cubic-bezier(
                        0.2,
                        0.8,
                        0.2,
                        1
                    ),

                    box-shadow 0.18s ease,

                    opacity 0.15s ease;
            }

            .web-preview-floating-button.dragging {
                cursor: grabbing;

                transform:
                    translate3d(0, 0, 0)
                    scale(1.08);

                box-shadow:
                    0 8px 24px
                    rgba(0, 0, 0, 0.45);
            }

            .web-preview-floating-button svg {
                width: 30px;
                height: 30px;

                pointer-events: none;

                transition:
                    transform 0.18s ease;
            }

            .web-preview-floating-button.dragging svg {
                transform: scale(1.04);
            }
        `,document.head.appendChild(e);let t=document.createElement("button");t.className="web-preview-floating-button",t.type="button",t.title="Web Preview",t.setAttribute("aria-label","Open Web Preview"),t.innerHTML=`
            <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
            >

                <circle
                    cx="12"
                    cy="12"
                    r="9"
                ></circle>

                <line
                    x1="3"
                    y1="12"
                    x2="21"
                    y2="12"
                ></line>

                <path
                    d="
                        M12 3
                        c2.5 2.5
                        3.8 5.5
                        3.8 9
                        s-1.3 6.5
                        -3.8 9
                    "
                ></path>

                <path
                    d="
                        M12 3
                        c-2.5 2.5
                        -3.8 5.5
                        -3.8 9
                        s1.3 6.5
                        3.8 9
                    "
                ></path>

            </svg>
        `,this.setupDragging(t),document.body.appendChild(t),this.floatingButton=t,this.floatingButtonStyle=e}setupDragging(e){e.addEventListener("pointerdown",t=>{this.isDragging=!0,this.hasMoved=!1;let i=e.getBoundingClientRect();this.dragOffsetX=t.clientX-i.left,this.dragOffsetY=t.clientY-i.top,e.classList.add("dragging"),e.setPointerCapture(t.pointerId)}),e.addEventListener("pointermove",t=>{if(!this.isDragging)return;(Math.abs(t.movementX||0)>1||Math.abs(t.movementY||0)>1)&&(this.hasMoved=!0);let i=e.offsetWidth,r=e.offsetHeight,n=10,a=t.clientX-this.dragOffsetX,o=t.clientY-this.dragOffsetY,p=window.innerWidth-i-n,d=window.innerHeight-r-n;a=Math.max(n,Math.min(a,p)),o=Math.max(n,Math.min(o,d)),e.style.left=`${a}px`,e.style.top=`${o}px`,e.style.right="auto",e.style.bottom="auto",this.buttonX=a,this.buttonY=o}),e.addEventListener("pointerup",t=>{this.isDragging&&(this.isDragging=!1,e.classList.remove("dragging"),e.hasPointerCapture(t.pointerId)&&e.releasePointerCapture(t.pointerId))}),e.addEventListener("pointercancel",()=>{this.isDragging=!1,e.classList.remove("dragging")}),e.addEventListener("click",t=>{if(this.hasMoved){t.preventDefault(),t.stopPropagation(),this.hasMoved=!1;return}this.open()})}registerCommands(){this.commands.addCommand({name:"web-preview.open",description:"Open Web Preview",exec:()=>{this.open()}})}open(){this.page&&this.page.show()}close(){var e;!this.page||!this.previewOpen||((e=this.actionStack)==null||e.remove(this.actionId),this.previewOpen=!1,this.closeMenu(),this.page.hide(),this.showFloatingButton())}closeFromBack(){this.page&&(this.previewOpen=!1,this.closeMenu(),this.page.hide(),this.showFloatingButton())}goBack(){if(this.iframe)try{this.iframe.contentWindow.history.back()}catch{}}goForward(){if(this.iframe)try{this.iframe.contentWindow.history.forward()}catch{}}async detectLocalServer(){this.hideEmptyState(),this.setDetecting(!0);for(let e of this.localPorts){let t=`http://localhost:${e}`;if(await this.checkServer(t))return this.saveUrl(t),this.urlInput.value=t,this.iframe.src=t,this.setDetecting(!1),t}return this.setDetecting(!1),this.showEmptyState(),null}checkServer(e){return new Promise(t=>{let i=new AbortController,r=setTimeout(()=>{i.abort(),t(!1)},1200);fetch(e,{method:"GET",mode:"no-cors",cache:"no-store",signal:i.signal}).then(()=>{clearTimeout(r),t(!0)}).catch(()=>{clearTimeout(r),t(!1)})})}loadUrl(){let e=this.urlInput.value.trim();e&&(!e.startsWith("http://")&&!e.startsWith("https://")&&(e=`http://${e}`),this.urlInput.value=e,this.saveUrl(e),this.hideEmptyState(),this.iframe.src=e)}refresh(){this.iframe&&(this.hideEmptyState(),this.iframe.src=this.iframe.src)}setDetecting(e){var i;let t=(i=this.page)==null?void 0:i.querySelector(".web-preview-detect");t&&(t.disabled=e,t.querySelector(".web-preview-menu-item-left span:last-child").textContent=e?"Scanning...":"Detect Local Server")}showEmptyState(){this.iframe&&(this.iframe.src="about:blank")}hideEmptyState(){this.iframe}getSavedUrl(){try{return localStorage.getItem(this.storageKey)}catch{return null}}saveUrl(e){try{localStorage.setItem(this.storageKey,e)}catch{}}hideFloatingButton(){this.floatingButton&&(this.floatingButton.style.display="none")}showFloatingButton(){this.floatingButton&&(this.floatingButton.style.display="flex")}destroy(){var e,t;(e=this.actionStack)==null||e.remove(this.actionId),(t=this.commands)==null||t.removeCommand("web-preview.open"),this.floatingButton&&(this.floatingButton.remove(),this.floatingButton=null),this.floatingButtonStyle&&(this.floatingButtonStyle.remove(),this.floatingButtonStyle=null),this.page&&(this.page.innerHTML=""),this.page=null,this.commands=null,this.actionStack=null,this.iframe=null,this.urlInput=null,this.backButton=null,this.refreshButton=null,this.menuButton=null,this.menu=null}};if(window.acode){let s=new h;acode.setPluginInit(l.id,async(e,t,{cacheFileUrl:i,cacheFile:r})=>{s.baseUrl=e.endsWith("/")?e:`${e}/`,await s.init(t)}),acode.setPluginUnmount(l.id,()=>{s.destroy()})}})();
